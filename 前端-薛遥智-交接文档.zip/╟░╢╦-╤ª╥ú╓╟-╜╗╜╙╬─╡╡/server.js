const express = require('express')
const path = require('path');
const app = express()
const server = require('http').Server(app);



app.use('/', express.static(path.resolve('build')))


server.listen(3000, function () {
    console.log('Node app start at port 3000')
})

